# WeatherAPP
a android studio weather app.
